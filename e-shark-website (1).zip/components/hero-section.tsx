'use client'

import { Button } from '@/components/ui/button'
import { ArrowRight, Play } from 'lucide-react'
import RealisticShark from './realistic-shark'
import { useLanguage } from './language-provider'

export default function HeroSection() {
  const { t, language } = useLanguage()

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50 dark:from-slate-900 dark:via-slate-800 dark:to-slate-900 overflow-hidden transition-colors duration-500">
      {/* Enhanced Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-96 h-96 bg-blue-200/40 dark:bg-blue-500/20 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-xl opacity-40 animate-blob"></div>
        <div className="absolute top-40 right-10 w-80 h-80 bg-orange-200/40 dark:bg-orange-500/20 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-xl opacity-40 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-blue-300/30 dark:bg-blue-600/15 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-xl opacity-30 animate-blob animation-delay-4000"></div>
        <div className="absolute top-1/2 right-1/4 w-64 h-64 bg-purple-200/25 dark:bg-purple-500/15 rounded-full mix-blend-multiply dark:mix-blend-screen filter blur-xl opacity-25 animate-blob animation-delay-6000"></div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-blue-400/30 dark:bg-blue-300/40 rounded-full animate-float-particle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`
            }}
          />
        ))}
      </div>

      <div className="relative container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Left Content */}
          <div className={`space-y-8 animate-slide-in-left ${language === 'ar' ? 'text-right' : ''}`}>
            <div className="space-y-6">
              <div className={`inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-100 to-orange-100 dark:from-blue-900/30 dark:to-orange-900/30 text-blue-800 dark:text-blue-200 rounded-full text-sm font-medium hover:scale-105 transition-all duration-300 cursor-pointer shadow-lg dark:shadow-blue-500/10 ${
                language === 'ar' ? 'font-arabic' : ''
              }`}>
                {t('hero.badge')}
              </div>
              <h1 className={`text-4xl md:text-6xl lg:text-7xl font-bold text-blue-900 dark:text-blue-100 leading-tight ${
                language === 'ar' ? 'font-arabic-bold' : ''
              }`}>
                <span className="animate-fade-in-up">{t('hero.title')}</span>
                <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-orange-500 dark:from-blue-400 dark:to-orange-400 animate-gradient-x animate-fade-in-up animation-delay-300">
                  {t('hero.titleHighlight')}
                </span>
              </h1>
              <p className={`text-xl text-gray-600 dark:text-gray-300 leading-relaxed max-w-2xl animate-fade-in-up animation-delay-600 ${
                language === 'ar' ? 'font-arabic' : ''
              }`}>
                {t('hero.description')}
              </p>
            </div>

            <div className={`flex flex-col sm:flex-row gap-4 animate-fade-in-up animation-delay-900 ${
              language === 'ar' ? 'sm:flex-row-reverse' : ''
            }`}>
              <Button 
                size="lg" 
                className={`bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 dark:from-blue-500 dark:to-blue-600 dark:hover:from-blue-600 dark:hover:to-blue-700 text-white px-8 py-4 text-lg hover:scale-105 transition-all duration-300 shadow-xl hover:shadow-2xl dark:shadow-blue-500/25 group rounded-xl ${
                  language === 'ar' ? 'font-arabic' : ''
                }`}
              >
                {t('hero.startTrial')}
                <ArrowRight className={`w-5 h-5 group-hover:translate-x-1 transition-transform ${
                  language === 'ar' ? 'mr-2 group-hover:-translate-x-1' : 'ml-2'
                }`} />
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className={`border-2 border-blue-600 dark:border-blue-400 text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 px-8 py-4 text-lg hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl dark:shadow-blue-500/10 group rounded-xl ${
                  language === 'ar' ? 'font-arabic' : ''
                }`}
              >
                <Play className={`w-5 h-5 group-hover:scale-110 transition-transform ${
                  language === 'ar' ? 'ml-2' : 'mr-2'
                }`} />
                {t('hero.watchDemo')}
              </Button>
            </div>

            <div className={`flex items-center pt-8 animate-fade-in-up animation-delay-1200 ${
              language === 'ar' ? 'flex-row-reverse space-x-reverse space-x-8' : 'space-x-8'
            }`}>
              <div className={`text-center group cursor-pointer ${language === 'ar' ? 'text-right' : ''}`}>
                <div className={`text-3xl font-bold text-blue-900 dark:text-blue-100 group-hover:scale-110 transition-transform ${
                  language === 'ar' ? 'font-arabic-bold' : ''
                }`}>10K+</div>
                <div className={`text-sm text-gray-600 dark:text-gray-400 ${
                  language === 'ar' ? 'font-arabic' : ''
                }`}>{t('hero.educators')}</div>
              </div>
              <div className={`text-center group cursor-pointer ${language === 'ar' ? 'text-right' : ''}`}>
                <div className={`text-3xl font-bold text-blue-900 dark:text-blue-100 group-hover:scale-110 transition-transform ${
                  language === 'ar' ? 'font-arabic-bold' : ''
                }`}>500K+</div>
                <div className={`text-sm text-gray-600 dark:text-gray-400 ${
                  language === 'ar' ? 'font-arabic' : ''
                }`}>{t('hero.students')}</div>
              </div>
              <div className={`text-center group cursor-pointer ${language === 'ar' ? 'text-right' : ''}`}>
                <div className={`text-3xl font-bold text-blue-900 dark:text-blue-100 group-hover:scale-110 transition-transform ${
                  language === 'ar' ? 'font-arabic-bold' : ''
                }`}>$2M+</div>
                <div className={`text-sm text-gray-600 dark:text-gray-400 ${
                  language === 'ar' ? 'font-arabic' : ''
                }`}>{t('hero.revenue')}</div>
              </div>
            </div>
          </div>

          {/* Right Content - Realistic Shark */}
          <div className="relative flex justify-center items-center animate-slide-in-right">
            <RealisticShark />
          </div>
        </div>
      </div>
    </section>
  )
}
