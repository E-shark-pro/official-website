'use client'

import { useEffect, useState, useRef } from 'react'

export default function RealisticShark() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isHovered, setIsHovered] = useState(false)
  const sharkRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (sharkRef.current) {
        const rect = sharkRef.current.getBoundingClientRect()
        const centerX = rect.left + rect.width / 2
        const centerY = rect.top + rect.height / 2
        
        setMousePosition({
          x: (e.clientX - centerX) * 0.05,
          y: (e.clientY - centerY) * 0.05
        })
      }
    }

    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  return (
    <div 
      ref={sharkRef}
      className="relative w-full h-96 flex items-center justify-center"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Water Effect Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-100/30 to-blue-300/50 rounded-full animate-pulse-slow overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer"></div>
      </div>

      {/* Main Shark Container */}
      <div 
        className={`relative transition-all duration-700 ease-out ${
          isHovered ? 'scale-110' : 'scale-100'
        }`}
        style={{
          transform: `translate(${mousePosition.x}px, ${mousePosition.y}px) ${
            isHovered ? 'scale(1.1)' : 'scale(1)'
          }`
        }}
      >
        <svg
          viewBox="0 0 500 350"
          className="w-96 h-80 drop-shadow-2xl"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Gradients and Filters */}
          <defs>
            <linearGradient id="sharkBodyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e40af" />
              <stop offset="30%" stopColor="#3b82f6" />
              <stop offset="70%" stopColor="#1e3a8a" />
              <stop offset="100%" stopColor="#1e293b" />
            </linearGradient>
            <linearGradient id="sharkBellyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f1f5f9" />
              <stop offset="50%" stopColor="#e2e8f0" />
              <stop offset="100%" stopColor="#cbd5e1" />
            </linearGradient>
            <linearGradient id="finGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f97316" />
              <stop offset="50%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#c2410c" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge> 
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
            <filter id="shadow">
              <feDropShadow dx="2" dy="4" stdDeviation="3" floodOpacity="0.3"/>
            </filter>
          </defs>

          {/* Shark Body Shadow */}
          <ellipse
            cx="250"
            cy="180"
            rx="140"
            ry="70"
            fill="rgba(0,0,0,0.1)"
            transform="translate(5, 5)"
            className="animate-float-slow"
          />

          {/* Main Body */}
          <ellipse
            cx="250"
            cy="175"
            rx="140"
            ry="70"
            fill="url(#sharkBodyGradient)"
            filter="url(#shadow)"
            className="animate-float"
          />

          {/* Belly */}
          <ellipse
            cx="250"
            cy="200"
            rx="120"
            ry="45"
            fill="url(#sharkBellyGradient)"
            opacity="0.8"
            className="animate-float"
          />

          {/* Head */}
          <ellipse
            cx="350"
            cy="175"
            rx="90"
            ry="55"
            fill="url(#sharkBodyGradient)"
            filter="url(#shadow)"
            className="animate-float"
          />

          {/* Snout */}
          <ellipse
            cx="420"
            cy="175"
            rx="40"
            ry="25"
            fill="url(#sharkBodyGradient)"
            className="animate-float"
          />

          {/* Tail */}
          <g className="animate-tail-sway">
            <path
              d="M110 175 L40 140 L60 175 L40 210 Z"
              fill="url(#sharkBodyGradient)"
              filter="url(#shadow)"
            />
            <path
              d="M110 175 L50 155 L65 175 L50 195 Z"
              fill="url(#finGradient)"
              opacity="0.7"
            />
          </g>

          {/* Dorsal Fin */}
          <path
            d="M220 105 L270 70 L300 125 L250 140 Z"
            fill="url(#finGradient)"
            filter="url(#shadow)"
            className="animate-fin-wave"
          />

          {/* Pectoral Fins */}
          <ellipse
            cx="200"
            cy="220"
            rx="45"
            ry="20"
            fill="url(#finGradient)"
            transform="rotate(25 200 220)"
            filter="url(#shadow)"
            className="animate-fin-flutter"
          />
          <ellipse
            cx="200"
            cy="130"
            rx="45"
            ry="20"
            fill="url(#finGradient)"
            transform="rotate(-25 200 130)"
            filter="url(#shadow)"
            className="animate-fin-flutter animation-delay-500"
          />

          {/* Gills */}
          <g opacity="0.6">
            <path d="M300 150 Q310 155 300 160" stroke="#1e293b" strokeWidth="2" fill="none" />
            <path d="M310 155 Q320 160 310 165" stroke="#1e293b" strokeWidth="2" fill="none" />
            <path d="M320 160 Q330 165 320 170" stroke="#1e293b" strokeWidth="2" fill="none" />
          </g>

          {/* Eye */}
          <circle
            cx="380"
            cy="155"
            r="18"
            fill="white"
            filter="url(#shadow)"
          />
          <circle
            cx="385"
            cy="155"
            r="12"
            fill="#1e40af"
            className={isHovered ? 'animate-eye-focus' : 'animate-eye-blink'}
          />
          <circle
            cx="388"
            cy="150"
            r="4"
            fill="white"
            className="animate-sparkle"
          />

          {/* Mouth */}
          <path
            d="M420 185 Q440 195 420 205"
            stroke="#1e293b"
            strokeWidth="3"
            fill="none"
            className="animate-mouth-move"
          />

          {/* Teeth */}
          <g opacity="0.8">
            <path d="M425 190 L427 195 L429 190" fill="white" />
            <path d="M430 192 L432 197 L434 192" fill="white" />
            <path d="M435 190 L437 195 L439 190" fill="white" />
          </g>

          {/* Bubbles */}
          <g className="animate-bubbles">
            <circle cx="460" cy="120" r="6" fill="#60a5fa" opacity="0.7">
              <animate attributeName="cy" values="120;80;120" dur="3s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.7;0.3;0.7" dur="3s" repeatCount="indefinite" />
            </circle>
            <circle cx="470" cy="140" r="4" fill="#3b82f6" opacity="0.6">
              <animate attributeName="cy" values="140;100;140" dur="2.5s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.6;0.2;0.6" dur="2.5s" repeatCount="indefinite" />
            </circle>
            <circle cx="450" cy="130" r="3" fill="#1d4ed8" opacity="0.8">
              <animate attributeName="cy" values="130;90;130" dur="2s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.8;0.3;0.8" dur="2s" repeatCount="indefinite" />
            </circle>
            <circle cx="465" cy="110" r="2" fill="#1e40af" opacity="0.5">
              <animate attributeName="cy" values="110;70;110" dur="1.8s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.5;0.1;0.5" dur="1.8s" repeatCount="indefinite" />
            </circle>
          </g>
        </svg>

        {/* Floating Learning Elements */}
        <div className="absolute top-8 right-8 animate-float-up">
          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl shadow-xl border-2 border-blue-200 hover:scale-110 transition-all duration-300 cursor-pointer">
            <span className="text-3xl">📚</span>
          </div>
        </div>
        
        <div className="absolute bottom-12 left-8 animate-float-up animation-delay-1000">
          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl shadow-xl border-2 border-orange-200 hover:scale-110 transition-all duration-300 cursor-pointer">
            <span className="text-3xl">🎓</span>
          </div>
        </div>
        
        <div className="absolute top-1/2 right-4 animate-float-up animation-delay-2000">
          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl shadow-xl border-2 border-blue-200 hover:scale-110 transition-all duration-300 cursor-pointer">
            <span className="text-3xl">💡</span>
          </div>
        </div>

        <div className="absolute bottom-1/3 left-12 animate-float-up animation-delay-1500">
          <div className="bg-white/90 backdrop-blur-sm p-4 rounded-2xl shadow-xl border-2 border-orange-200 hover:scale-110 transition-all duration-300 cursor-pointer">
            <span className="text-3xl">🚀</span>
          </div>
        </div>
      </div>

      {/* Ripple Effect */}
      {isHovered && (
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 border-4 border-blue-400/30 rounded-full animate-ripple"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-4 border-blue-300/20 rounded-full animate-ripple animation-delay-300"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 border-4 border-blue-200/10 rounded-full animate-ripple animation-delay-600"></div>
        </div>
      )}
    </div>
  )
}
